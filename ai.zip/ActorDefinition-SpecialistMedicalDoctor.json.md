# Specialist medical doctor - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Specialist medical doctor**

## : Specialist medical doctor - JSON Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw json](ActorDefinition-SpecialistMedicalDoctor.json) | [Download](ActorDefinition-SpecialistMedicalDoctor.json)

