# Key populations - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Key populations**

## : Key populations - JSON Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw json](ActorDefinition-KeyPopulations.json) | [Download](ActorDefinition-KeyPopulations.json)

