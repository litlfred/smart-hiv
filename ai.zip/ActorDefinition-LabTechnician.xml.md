# Lab technician - XML Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Lab technician**

## : Lab technician - XML Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw xml](ActorDefinition-LabTechnician.xml) | [Download](ActorDefinition-LabTechnician.xml)

