# Client - TTL Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Client**

## : Client - TTL Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw ttl](ActorDefinition-Client.ttl) | [Download](ActorDefinition-Client.ttl)

