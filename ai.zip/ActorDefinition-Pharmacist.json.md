# Pharmacist - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Pharmacist**

## : Pharmacist - JSON Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw json](ActorDefinition-Pharmacist.json) | [Download](ActorDefinition-Pharmacist.json)

