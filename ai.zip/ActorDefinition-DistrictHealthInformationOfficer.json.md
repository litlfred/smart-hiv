# District health information officer - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **District health information officer**

## : District health information officer - JSON Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw json](ActorDefinition-DistrictHealthInformationOfficer.json) | [Download](ActorDefinition-DistrictHealthInformationOfficer.json)

