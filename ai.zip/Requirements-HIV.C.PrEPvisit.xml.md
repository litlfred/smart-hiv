# PrEP visit - XML Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PrEP visit**

## : PrEP visit - XML Representation

| |
| :--- |
| Active as of 2026-10-14 |

[Raw xml](Requirements-HIV.C.PrEPvisit.xml) | [Download](Requirements-HIV.C.PrEPvisit.xml)

