# Other priority populations ValueSet - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Other priority populations ValueSet**

## ValueSet: Other priority populations ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/ValueSet/HIV.Config.DE19 | *Version*:0.4.4 |
| Active as of 2026-10-14 | *Computable Name*:HIVConfigDE19 |

 
Value set of other populations of priority of HIV prevention and care in local context (provided during adaptation) 

 **References** 

* [HIV.Configuration](StructureDefinition-HIVConfiguration.md)

### Logical Definition (CLD)

This ValueSet does not have a formal definition; instead, the value set must be prepared by hand using these instructions.

This should be a context-specific list of other priority populations

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HIV.Config.DE19",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "This should be a context-specific list of other priority populations"
  }],
  "url" : "http://smart.who.int/hiv/ValueSet/HIV.Config.DE19",
  "version" : "0.4.4",
  "name" : "HIVConfigDE19",
  "title" : "Other priority populations ValueSet",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-14T11:09:56+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value set of other populations of priority of HIV prevention and care in local context (provided during adaptation)"
}

```
