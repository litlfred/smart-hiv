# Trained non-physician clinician - TTL Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trained non-physician clinician**

## : Trained non-physician clinician - TTL Representation

| |
| :--- |
| Draft as of 2026-10-14 |

[Raw ttl](ActorDefinition-TrainedNonPhysicianClinician.ttl) | [Download](ActorDefinition-TrainedNonPhysicianClinician.ttl)

