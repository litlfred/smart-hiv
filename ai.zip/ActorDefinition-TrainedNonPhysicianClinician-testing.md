# Trained non-physician clinician - Testing - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trained non-physician clinician**

## ActorDefinition: Trained non-physician clinician - Testing 

| |
| :--- |
| Draft as of 2026-10-14 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

